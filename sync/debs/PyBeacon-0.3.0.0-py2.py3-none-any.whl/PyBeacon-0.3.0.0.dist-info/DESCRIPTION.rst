Python package for scanning and advertising     Eddystone-URLs and Eddystone-UID.


