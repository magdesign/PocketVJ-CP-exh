"""Module configuration."""
__title__ = 'PyBeacon'
__version__ = '0.3.0.0'
__build__ = 0x016
__author__ = 'forksociety'
__license__ = 'GNU Affero General Public License v3 or later (AGPLv3+)'
