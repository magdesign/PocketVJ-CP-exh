# game

Demonstrates a seamless background image that can be scolled in any
direction. As well as animated sprites. Change direction of travel using
',' and '.' keys. Press 'Esc' to exit.

