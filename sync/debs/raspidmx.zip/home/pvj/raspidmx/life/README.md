# life

A version of Conway's game of life. The code starts with a random image and
continues to iterate. Press 'p' to pause and then press the space bar to 
step. Press 'Esc' to exit the game.

