# pngresize

Example of using an offscreen display to resize an image. The program reads
a PNG image and resizes it to the specified width and height.
