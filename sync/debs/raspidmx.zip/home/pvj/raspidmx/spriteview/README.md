# spriteview

Animated sprite viewer. 

If in interactive mode (default): Press 'Esc' to exit. Press 'p' to pause and 
then use space bar to step through animation.

If in non-interactive mode (-n): Set a timeout=0 "-t 0" to run infinitelly or
different to 0 to run for a certain time, e.g: "-t 3000" to run for 3 seconds.
An interval between animation steps can be set, e.g: "-i 500" (it changes after 0.5 s).

