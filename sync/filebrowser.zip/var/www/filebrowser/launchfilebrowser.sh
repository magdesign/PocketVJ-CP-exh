#!/bin/bash


#this script launches the filebrowser instance on port :8060


/var/www/filebrowser/filebrowser config init --auth.method=noauth --branding.name "PocketVJ" --branding.disableExternal

/var/www/filebrowser/filebrowser config set --auth.method=noauth --branding.name "PocketVJ"     --branding.disableExternal

/var/www/filebrowser/filebrowser -a 0.0.0.0 -p 8060 -r /media/
