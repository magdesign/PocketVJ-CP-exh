## Travis CI

[ ] Change user to `pi` when installng
[ ] Enable SSH access

