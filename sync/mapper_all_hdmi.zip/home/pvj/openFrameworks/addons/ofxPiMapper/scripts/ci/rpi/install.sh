#!/bin/bash

echo "Hello! This is rpi install.sh script."
