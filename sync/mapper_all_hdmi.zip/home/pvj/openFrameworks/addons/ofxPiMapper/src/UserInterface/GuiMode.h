#pragma once

namespace ofx {
namespace piMapper {

struct GuiMode {
	enum {
		NONE, TEXTURE_MAPPING, PROJECTION_MAPPING, SOURCE_SELECTION
	};
};

} // namespace piMapper
} // namespace ofx