# Camera Example

This example demonstrates the possibility to use camera input as a texture source. Make sure you clone the [ofxRPiCameraVideoGrabber](https://github.com/jvcleave/ofxRPiCameraVideoGrabber) addon into your `openFrameworks/addons` folder before compiling on Raspberry Pi.

```
cd openFrameworks/addons
git clone https://github.com/jvcleave/ofxRPiCameraVideoGrabber.git
```

